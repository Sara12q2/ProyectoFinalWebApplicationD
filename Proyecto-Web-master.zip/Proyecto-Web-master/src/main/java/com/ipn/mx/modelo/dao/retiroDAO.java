
package com.ipn.mx.modelo.dao;

import com.ipn.mx.modelo.dto.retiroDTO;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author LENOVO
 */
public class retiroDAO {
    private static final String SQL_INSERT = "INSERT INTO retiro(\n" +
"	\"fechaRetiro\", \"horaRetiro\", \"montoRetiro\", \"conceptoRetiro\", \"idCategoria\")\n" +
"	VALUES (?, ?, ?, ?, ?);	";
    private static final String SQL_UPDATE = "UPDATE retiro\n" +
"	SET  \"fechaRetiro\"=?, \"horaRetiro\"=?, \"montoRetiro\"=?, \"conceptoRetiro\"=?, \"idCategoria\"=?\n" +
"	WHERE \"idRetiro\" = ?;";
    private static final String SQL_SELECT = "SELECT \"idRetiro\", \"fechaRetiro\", \"horaRetiro\", \"montoRetiro\", \"conceptoRetiro\", \"idCategoria\"\n" +
"	FROM retiro\n" +
"	WHERE \"idRetiro\" = ?;";
    private static final String SQL_SELECT_ALL = "SELECT \"idRetiro\", \"fechaRetiro\", \"horaRetiro\", \"montoRetiro\", \"conceptoRetiro\", \"idCategoria\"\n" +
"	FROM retiro;";
    private static final String SQL_DELETE = "DELETE FROM retiro\n" +
"	WHERE \"idRetiro\" = ?;";
    
    private Connection conexion;
        
    public Connection obtenerConexion() { ////////////////////////////////////
        String usuario = "tsrjuulvshvrdb";
        String clave = "fcddef80d1bcca1ee0210d0ff13171925557c0092d0c79a2b89da321f88f9ada";
        String url = "jdbc:postgresql://ec2-34-236-87-247.compute-1.amazonaws.com:5432/d3at1e0qnhrgfe";
        String driverPostgreSql = "org.postgresql.Driver";
        try {
            Class.forName(driverPostgreSql);
            conexion = DriverManager.getConnection(url, usuario, clave);
        } catch (ClassNotFoundException | SQLException e) {
            Logger.getLogger(retiroDAO.class.getName()).log(Level.SEVERE, null, e);
        }
        return conexion;
    }

        public void create(retiroDTO dto) throws SQLException {
        obtenerConexion();
        CallableStatement ps = null;
        try {
            ps = conexion.prepareCall(SQL_INSERT);
            ps.setDate(1,dto.getEntidad().getFechaRetiro());
            ps.setTime(2, dto.getEntidad().getHoraRetiro());
            ps.setDouble(3, dto.getEntidad().getMontoRetiro());
            ps.setString(4, dto.getEntidad().getConceptoRetiro());
            ps.setInt(5, dto.getEntidad().getIdCategoria());

            ps.executeUpdate();

        } finally {
            if (ps != null) {
                ps.close();
            }
            if (conexion != null) {
                conexion.close();
            }

        }
    }

        public void update(retiroDTO dto) throws SQLException {
            obtenerConexion();
            CallableStatement ps = null;
            try {
                ps = conexion.prepareCall(SQL_UPDATE);
                ps.setDate(1, dto.getEntidad().getFechaRetiro());
                ps.setTime(2, dto.getEntidad().getHoraRetiro());
                ps.setDouble(3, dto.getEntidad().getMontoRetiro());
                ps.setString(4, dto.getEntidad().getConceptoRetiro());
                ps.setInt(5, dto.getEntidad().getIdCategoria());
                ps.setInt(6, dto.getEntidad().getIdRetiro());

                ps.executeUpdate();

            } finally {
                if (ps != null) {
                    ps.close();
                }
                if (conexion != null) {
                    conexion.close();
                }

            }
        }
    public void delete(retiroDTO dto) throws SQLException {
        obtenerConexion();
        CallableStatement ps = null;
        try {
            ps=conexion.prepareCall(SQL_DELETE);
            ps.setInt(1, dto.getEntidad().getIdRetiro());
            ps.executeUpdate();
            
        } finally {
            if (ps != null) {
                ps.close();
            }
            if (conexion != null) {
                conexion.close();
            }

        }
        
    }
    
    public retiroDTO read(retiroDTO dto) throws SQLException {
        obtenerConexion();
        CallableStatement ps = null;
        ResultSet rs = null;
        try{
            ps = conexion.prepareCall(SQL_SELECT);
            ps.setInt(1, dto.getEntidad().getIdRetiro());
            rs = ps.executeQuery();
            List resultados = obtenerResultados(rs);
            if(resultados.size()>0){
                return (retiroDTO)resultados.get(0);
            }else{
                return null;
            }
        }finally{
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (conexion != null) conexion.close();
        }
    }

    public List readAll() throws SQLException {
        obtenerConexion();
        CallableStatement ps = null;
        ResultSet rs = null;
        try{
            ps=conexion.prepareCall(SQL_SELECT_ALL);
            rs = ps.executeQuery();
            List resultados = obtenerResultados(rs);
            if(resultados.size()>0){
                return resultados;
            }else{
                return null;
            }
        }finally{
            if (rs != null) rs.close();
            if (ps != null) ps.close();
            if (conexion != null) conexion.close();
        }
    }
    
        private List obtenerResultados(ResultSet rs)throws SQLException{
        List resultados = new ArrayList();
        while(rs.next()){
            retiroDTO dto = new retiroDTO();
            dto.getEntidad().setIdRetiro(rs.getInt("idRetiro"));
            dto.getEntidad().setConceptoRetiro(rs.getString("conceptoRetiro"));
            dto.getEntidad().setMontoRetiro(rs.getInt("montoRetiro"));
            dto.getEntidad().setIdCategoria(rs.getInt("idCategoria"));
            dto.getEntidad().setFechaRetiro(rs.getDate("FechaRetiro"));
            dto.getEntidad().setHoraRetiro(rs.getTime("HoraRetiro"));
            
            resultados.add(dto);
        }
        
        return resultados;
    }

    public static void main(String[] args) throws SQLException {
        retiroDTO dto = new retiroDTO();
        dto.getEntidad().setConceptoRetiro("retiro por x cosa");
        dto.getEntidad().setMontoRetiro(9000);
        
        
        dto.getEntidad().setFechaRetiro(new Date(System.currentTimeMillis()));
        dto.getEntidad().setHoraRetiro(new Time(System.currentTimeMillis()));
        dto.getEntidad().setIdCategoria(3);

        retiroDAO dao = new retiroDAO();

        dao.create(dto);
        System.out.println(dao.readAll());

    }

    
}
