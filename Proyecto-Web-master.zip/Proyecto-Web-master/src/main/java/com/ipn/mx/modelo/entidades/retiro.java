
package com.ipn.mx.modelo.entidades;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Time;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * @author LENOVO
 */
@NoArgsConstructor
@Data
public class retiro implements Serializable{
    private int idRetiro;
    private String conceptoRetiro;
    private double montoRetiro;
    Date FechaRetiro;
    Time HoraRetiro;
    private int idCategoria;
    
}
