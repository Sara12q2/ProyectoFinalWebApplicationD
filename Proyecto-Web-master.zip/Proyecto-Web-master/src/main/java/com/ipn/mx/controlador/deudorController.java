/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ipn.mx.controlador;

import com.ipn.mx.modelo.dao.GraficaDAO;
import com.ipn.mx.modelo.dao.deudorDAO;
import com.ipn.mx.modelo.dto.GraficaDTO;
import com.ipn.mx.modelo.dto.deudorDTO;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperRunManager;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;

/**
 *
 * @author Pablo
 */
@WebServlet(name = "deudorController", urlPatterns = {"/deudorController"})

public class deudorController extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String accion = request.getParameter("accion");
        if (accion.equals("listaDeDeudores")) {
            listadoDeDeudores(request, response);
        } else {
            if (accion.equals("nuevo")) {
                agregarDeudor(request, response);
            } else {
                if (accion.equals("eliminar")) {
                    eliminarDeudor(request, response);
                } else {
                    if (accion.equals("actualizar")) {
                        actualizarDeudor(request, response);
                    } else {
                        if (accion.equals("guardar")) {
                            almacenarDeudor(request, response);
                        } else {
                            if (accion.equals("ver")) {
                                mostrarDeudor(request, response);
                            } else {
                                if (accion.equals("verReporte")) {
                                    mostrarReporteDeudor(request, response);
                                } else {
                                    if (accion.equals("graficar")) {
                                        mostrarGraficaDeudor(request, response);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

     // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    
    private void listadoDeDeudores(HttpServletRequest request, HttpServletResponse response) {
        try {
            deudorDAO dao = new deudorDAO();

            //System.out.println(dao.readAll());
            request.setAttribute("listaDeDeudores", dao.readAll());
            RequestDispatcher rd = request.getRequestDispatcher("/deudores/listaDeDeudores.jsp");
            rd.forward(request, response);
        } catch (ServletException | IOException | SQLException ex) {
            Logger.getLogger(deudorController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private void agregarDeudor(HttpServletRequest request, HttpServletResponse response) {
        RequestDispatcher rd = request.getRequestDispatcher("/deudores/deudoresForm.jsp");
        try {
            rd.forward(request, response);
        } catch (ServletException | IOException ex) {
            Logger.getLogger(deudorController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void eliminarDeudor(HttpServletRequest request, HttpServletResponse response) {
        try {
            deudorDAO dao = new deudorDAO();
            deudorDTO dto = new deudorDTO();
            dto.getEntidad().setIdDeudor(Integer.parseInt(request.getParameter("id")));

            dao.delete(dto);
            listadoDeDeudores(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(deudorController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void actualizarDeudor(HttpServletRequest request, HttpServletResponse response) {
        try {
            deudorDAO dao = new deudorDAO();
            deudorDTO dto = new deudorDTO();
            dto.getEntidad().setIdDeudor(Integer.parseInt(request.getParameter("id")));
            RequestDispatcher vista = request.getRequestDispatcher("deudores/deudoresForm.jsp");
            request.setAttribute("deudor", dao.read(dto));
            vista.forward(request, response);
        } catch (ServletException | IOException | SQLException ex) {
            Logger.getLogger(deudorController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void almacenarDeudor(HttpServletRequest request, HttpServletResponse response) {
        deudorDAO dao = new deudorDAO();
        deudorDTO dto = new deudorDTO();
      //dto.getEntidad().setIdDeudor(Integer.parseInt(request.getParameter("id")));
        dto.getEntidad().setConceptoDeudor(request.getParameter("txtConceptoDeudor"));
        dto.getEntidad().setMontoDeudor(Double.parseDouble(request.getParameter("txtMontoDeudor")));
        
        try {
            dao.create(dto);
            request.setAttribute("mensaje", "Deudor agregado con éxito");

            listadoDeDeudores(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(deudorController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void mostrarDeudor(HttpServletRequest request, HttpServletResponse response) {
        try {
            deudorDAO dao = new deudorDAO();
            deudorDTO dto = new deudorDTO();

            dto.getEntidad().setIdDeudor(Integer.parseInt(request.getParameter("id")));
            RequestDispatcher vista = request.getRequestDispatcher("deudores/datosDeudor.jsp");

            dao.read(dto);
            request.setAttribute("deudor", dto);
            vista.forward(request, response);
        } catch (SQLException | ServletException | IOException ex) {
            Logger.getLogger(deudorController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void mostrarReporteDeudor(HttpServletRequest request, HttpServletResponse response) {
        try {
            deudorDAO dao = new deudorDAO();
            ServletOutputStream sos = null;
            sos = response.getOutputStream();
            File reporte = new File(getServletConfig().getServletContext().getRealPath("/reportes/deudores.jasper"));
            byte[] b = JasperRunManager.runReportToPdf(reporte.getPath(), null, dao.obtenerConexion());
            response.setContentType("application/pdf");
            response.setContentLength(b.length);
            sos.write(b, 0, b.length);
            sos.flush();
            sos.close();
        } catch (JRException | IOException ex) {
            Logger.getLogger(deudorController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void mostrarGraficaDeudor(HttpServletRequest request, HttpServletResponse response) {
        try {
            JFreeChart grafica = ChartFactory.createPieChart("Productos por Categoria", obtenerDatosGraficaProductosPorCategoria(), true, true, Locale.getDefault());
            String archivo = getServletConfig().getServletContext().getRealPath("/grafica.png");

            ChartUtils.saveChartAsPNG(new File(archivo), grafica, 500, 500);
            RequestDispatcher vista = request.getRequestDispatcher("grafica.jsp");
            vista.forward(request, response);
        } catch (ServletException | IOException ex) {
            Logger.getLogger(deudorController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private PieDataset obtenerDatosGraficaProductosPorCategoria() {
        DefaultPieDataset dsPie = new DefaultPieDataset();
        GraficaDAO dao = new GraficaDAO();
        try {

            List datos = dao.obtenerDatosGrafica();
            for (int i = 0; i < datos.size(); i++) {
                GraficaDTO dto = (GraficaDTO) datos.get(i);
                dsPie.setValue(dto.getNombreCategoria(), dto.getCantidad());
            }

        } catch (SQLException ex) {
            Logger.getLogger(deudorController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return dsPie;
    }

}
