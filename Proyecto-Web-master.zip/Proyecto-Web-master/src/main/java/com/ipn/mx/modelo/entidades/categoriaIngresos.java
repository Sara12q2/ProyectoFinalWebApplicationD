/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ipn.mx.modelo.entidades;

import java.io.Serializable;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
 *
 * @author Pablo
 */
@NoArgsConstructor
@Data
public class categoriaIngresos implements Serializable{
    private int idCategoria;
    private String nombreCategoria;
    private String descripcionCategoria;
}
