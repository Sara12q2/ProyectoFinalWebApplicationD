/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ipn.mx.controlador;

import com.ipn.mx.modelo.dao.GraficaDAO;
import com.ipn.mx.modelo.dao.depositoDAO;
import com.ipn.mx.modelo.dto.GraficaDTO;
import com.ipn.mx.modelo.dto.depositoDTO;
import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperRunManager;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;

/**
 *
 * @author Pablo
 */
@WebServlet(name = "depositoController", urlPatterns = {"/depositoController"})



public class depositoController extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String accion = request.getParameter("accion");
        if (accion.equals("listaDeDepositos")) {
            listadoDeDepositos(request, response);
        } else {
            if (accion.equals("nuevo")) {
                agregarDeposito(request, response);
            } else {
                if (accion.equals("eliminar")) {
                    eliminarDeposito(request, response);
                } else {
                    if (accion.equals("actualizar")) {
                        actualizarDeposito(request, response);
                    } else {
                        if (accion.equals("guardar")) {
                            almacenarDeposito(request, response);
                        } else {
                            if (accion.equals("ver")) {
                                mostrarDeposito(request, response);
                            } else {
                                if (accion.equals("verReporte")) {
                                    mostrarReporteDeposito(request, response);
                                } else {
                                    if (accion.equals("graficar")) {
                                        mostrarGraficaDeposito(request, response);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
     // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>


    private void listadoDeDepositos(HttpServletRequest request, HttpServletResponse response) {
         depositoDAO dao = new depositoDAO();
        try {
           

            //System.out.println(dao.readAll());
            request.setAttribute("listaDeDepositos", dao.readAll());
            RequestDispatcher rd = request.getRequestDispatcher("/depositos/listaDeDepositos.jsp");
            rd.forward(request, response);
        } catch (ServletException | IOException | SQLException ex) {
            Logger.getLogger(depositoController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    private void agregarDeposito(HttpServletRequest request, HttpServletResponse response) {
         RequestDispatcher rd = request.getRequestDispatcher("/depositos/depositosForm.jsp");
        try {
           
            rd.forward(request, response);
        } catch (ServletException | IOException ex) {
            Logger.getLogger(depositoController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private void eliminarDeposito(HttpServletRequest request, HttpServletResponse response) {
        try {
            depositoDAO dao = new depositoDAO();
            depositoDTO dto = new depositoDTO();
            dto.getEntidad().setIdDeposito(Integer.parseInt(request.getParameter("id")));

            dao.delete(dto);
            listadoDeDepositos(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(depositoController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private void actualizarDeposito(HttpServletRequest request, HttpServletResponse response) {
            depositoDAO dao = new depositoDAO();
            depositoDTO dto = new depositoDTO();
            dto.getEntidad().setIdDeposito(Integer.parseInt(request.getParameter("id")));
            RequestDispatcher vista = request.getRequestDispatcher("depositos/depositosForm.jsp");
          
        try {
            dto=dao.read(dto);
            request.setAttribute("deposito", dto);
            vista.forward(request, response);
        } catch (SQLException | ServletException | IOException ex) {
            Logger.getLogger(depositoController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void almacenarDeposito(HttpServletRequest request, HttpServletResponse response) {
            depositoDAO dao = new depositoDAO();
            depositoDTO dto = new depositoDTO();
////            dto.getEntidad().setIdDeposito(Integer.parseInt(request.getParameter("id")));
            dto.getEntidad().setConceptoDeposito(request.getParameter("txtConceptoDeposito"));
            dto.getEntidad().setMontoDeposito(Double.parseDouble(request.getParameter("txtMontoDeposito")));
            dto.getEntidad().setFechaDeposito(new Date(System.currentTimeMillis()));
            dto.getEntidad().setHoraDeposito(new Time(System.currentTimeMillis()));
            dto.getEntidad().setIdCategoria(Integer.parseInt(request.getParameter("txtIdCategoria")));

        try {
            
            dao.create(dto);
            request.setAttribute("mensaje", "Deposito realizado con éxito");

            listadoDeDepositos(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(depositoController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void mostrarDeposito(HttpServletRequest request, HttpServletResponse response) {
            depositoDAO dao = new depositoDAO();
            depositoDTO dto = new depositoDTO();

            dto.getEntidad().setIdDeposito(Integer.parseInt(request.getParameter("id")));
            RequestDispatcher vista = request.getRequestDispatcher("depositos/datosDeposito.jsp");

        try {
            
            dao.read(dto);
            request.setAttribute("deposito", dto);
            vista.forward(request, response);
        } catch (SQLException | ServletException | IOException ex) {
            Logger.getLogger(depositoController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void mostrarReporteDeposito(HttpServletRequest request, HttpServletResponse response) {
        depositoDAO dao = new depositoDAO();
        try {
            
            ServletOutputStream sos = null;
            sos = response.getOutputStream();
            File reporte = new File(getServletConfig().getServletContext().getRealPath("/reportes/depositos.jasper"));
            byte[] b = JasperRunManager.runReportToPdf(reporte.getPath(), null, dao.obtenerConexion());
            response.setContentType("application/pdf");
            response.setContentLength(b.length);
            sos.write(b, 0, b.length);
            sos.flush();
            sos.close();
        } catch (IOException | JRException ex) {
            Logger.getLogger(depositoController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private void mostrarGraficaDeposito(HttpServletRequest request, HttpServletResponse response) {
        try {
            JFreeChart grafica = ChartFactory.createPieChart("Productos por Categoria", obtenerDatosGraficaProductosPorCategoria(), true, true, Locale.getDefault());
            String archivo = getServletConfig().getServletContext().getRealPath("/grafica.png");

            ChartUtils.saveChartAsPNG(new File(archivo), grafica, 500, 500);
            RequestDispatcher vista = request.getRequestDispatcher("grafica.jsp");
            vista.forward(request, response);
        } catch (IOException | ServletException ex) {
            Logger.getLogger(depositoController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private PieDataset obtenerDatosGraficaProductosPorCategoria() {
        DefaultPieDataset dsPie = new DefaultPieDataset();
        GraficaDAO dao = new GraficaDAO();
        try {

            List datos = dao.obtenerDatosGrafica();
            for (int i = 0; i < datos.size(); i++) {
                GraficaDTO dto = (GraficaDTO) datos.get(i);
                dsPie.setValue(dto.getNombreCategoria(), dto.getCantidad());
            }

        } catch (SQLException ex) {
            Logger.getLogger(depositoController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return dsPie;
    }

}

