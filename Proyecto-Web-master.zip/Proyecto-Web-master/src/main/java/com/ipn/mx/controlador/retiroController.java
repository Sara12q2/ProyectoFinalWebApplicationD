/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ipn.mx.controlador;

import com.ipn.mx.modelo.dao.GraficaDAO;
import com.ipn.mx.modelo.dao.retiroDAO;
import com.ipn.mx.modelo.dto.GraficaDTO;
import com.ipn.mx.modelo.dto.retiroDTO;
import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperRunManager;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;

/**
 *
 * @author Pablo
 */
@WebServlet(name = "retiroController", urlPatterns = {"/retiroController"})

public class retiroController extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String accion = request.getParameter("accion");
        if (accion.equals("listaDeRetiros")) {
            listadoDeRetiros(request, response);
        } else {
            if (accion.equals("nuevo")) {
                agregarRetiro(request, response);
            } else {
                if (accion.equals("eliminar")) {
                    eliminarRetiro(request, response);
                } else {
                    if (accion.equals("actualizar")) {
                        actualizarRetiro(request, response);
                    } else {
                        if (accion.equals("guardar")) {
                            almacenarRetiro(request, response);
                        } else {
                            if (accion.equals("ver")) {
                                mostrarRetiro(request, response);
                            } else {
                                if (accion.equals("verReporte")) {
                                    mostrarReporteRetiros(request, response);
                                } else {
                                    if (accion.equals("graficar")) {
                                        mostrarGraficaRetiros(request, response);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private void listadoDeRetiros(HttpServletRequest request, HttpServletResponse response) {
        retiroDAO dao = new retiroDAO();
        try {

            //System.out.println(dao.readAll());
            request.setAttribute("listaDeRetiros", dao.readAll());
            RequestDispatcher rd = request.getRequestDispatcher("/retiros/listaDeRetiros.jsp");
            rd.forward(request, response);
        } catch (SQLException | ServletException | IOException ex) {
            Logger.getLogger(retiroController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private void agregarRetiro(HttpServletRequest request, HttpServletResponse response) {
        try {
            RequestDispatcher rd = request.getRequestDispatcher("/retiros/retirosForm.jsp");
            rd.forward(request, response);
        } catch (ServletException | IOException ex) {
            Logger.getLogger(retiroController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private void eliminarRetiro(HttpServletRequest request, HttpServletResponse response) {
         try {
            retiroDAO dao = new retiroDAO();
            retiroDTO dto = new retiroDTO();
            dto.getEntidad().setIdRetiro(Integer.parseInt(request.getParameter("id")));

            dao.delete(dto);
            listadoDeRetiros(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(retiroController.class.getName()).log(Level.SEVERE, null, ex);
        }
//        
    }

    private void actualizarRetiro(HttpServletRequest request, HttpServletResponse response) {

        retiroDAO dao = new retiroDAO();
        retiroDTO dto = new retiroDTO();

        dto.getEntidad().setIdRetiro(Integer.parseInt(request.getParameter("id")));
        RequestDispatcher vista = request.getRequestDispatcher("retiros/retirosForm.jsp");
        try {
            request.setAttribute("retiro", dao.read(dto));
            vista.forward(request, response);
        } catch (SQLException | ServletException | IOException ex) {
            Logger.getLogger(retiroController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private void almacenarRetiro(HttpServletRequest request, HttpServletResponse response) {
         retiroDAO dao = new retiroDAO();
            retiroDTO dto = new retiroDTO();

//            dto.getEntidad().setIdRetiro(Integer.parseInt(request.getParameter("id")));
            dto.getEntidad().setConceptoRetiro(request.getParameter("txtConceptoRetiro"));
            dto.getEntidad().setMontoRetiro(Double.parseDouble(request.getParameter("txtMontoRetiro")));
            dto.getEntidad().setFechaRetiro(new Date(System.currentTimeMillis()));
            dto.getEntidad().setHoraRetiro(new Time(System.currentTimeMillis()));
            dto.getEntidad().setIdCategoria(Integer.parseInt(request.getParameter("txtIdCategoria")));

        try {
           
            dao.create(dto);
            request.setAttribute("mensaje", "Retiro realizado con éxito");

            listadoDeRetiros(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(retiroController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private void mostrarRetiro(HttpServletRequest request, HttpServletResponse response) {
        retiroDAO dao = new retiroDAO();
        retiroDTO dto = new retiroDTO();

        dto.getEntidad().setIdRetiro(Integer.parseInt(request.getParameter("id")));
        RequestDispatcher vista = request.getRequestDispatcher("retiros/datosRetiro.jsp");

        try {
            dao.read(dto);
            request.setAttribute("retiro", dto);
            vista.forward(request, response);
        } catch (SQLException | ServletException | IOException ex) {
            Logger.getLogger(retiroController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private void mostrarReporteRetiros(HttpServletRequest request, HttpServletResponse response) {
        retiroDAO dao=new retiroDAO();
        try {
            ServletOutputStream sos=response.getOutputStream();
            File reporte=new File(getServletConfig().getServletContext().getRealPath("/reportes/retiros.jasper"));
            byte[] b=JasperRunManager.runReportToPdf(reporte.getPath(), null, dao.obtenerConexion());
            response.setContentType("application/pdf");
            response.setContentLength(b.length);
            sos.write(b,0,b.length);
            sos.flush();
            sos.close();
        } catch (IOException | JRException ex) {
            Logger.getLogger(retiroController.class.getName()).log(Level.SEVERE, null, ex);
        }

//        retiroDAO dao = new retiroDAO();
//        try {
//            ServletOutputStream sos = null;
//            sos = response.getOutputStream();
//            File reporte = new File(getServletConfig().getServletContext().getRealPath("/reportes/retiros.jasper"));
//            byte[] b = JasperRunManager.runReportToPdf(reporte.getPath(), null, dao.obtenerConexion());
//            response.setContentType("application/pdf");
//            response.setContentLength(b.length);
//            sos.write(b, 0, b.length);
//            sos.flush();
//            sos.close();
//        } catch (IOException | JRException ex) {
//            Logger.getLogger(retiroController.class.getName()).log(Level.SEVERE, null, ex);
//        }

    }

    private void mostrarGraficaRetiros(HttpServletRequest request, HttpServletResponse response) {
        JFreeChart grafica = ChartFactory.createPieChart("Productos por Categoria", obtenerDatosGraficaProductosPorCategoria(), true, true, Locale.getDefault());
        String archivo = getServletConfig().getServletContext().getRealPath("/grafica.png");
        try {
            ChartUtils.saveChartAsPNG(new File(archivo), grafica, 500, 500);
            RequestDispatcher vista = request.getRequestDispatcher("grafica.jsp");
            vista.forward(request, response);

        } catch (IOException | ServletException ex) {
            Logger.getLogger(retiroController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private PieDataset obtenerDatosGraficaProductosPorCategoria() {
        DefaultPieDataset dsPie = new DefaultPieDataset();
        GraficaDAO dao = new GraficaDAO();
        try {
            List datos = dao.obtenerDatosGrafica();
            for (int i = 0; i < datos.size(); i++) {
                GraficaDTO dto = (GraficaDTO) datos.get(i);
                dsPie.setValue(dto.getNombreCategoria(), dto.getCantidad());
            }
        } catch (SQLException ex) {
            Logger.getLogger(retiroController.class.getName()).log(Level.SEVERE, null, ex);
        }

        return dsPie;

    }

}
